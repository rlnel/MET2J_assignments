var searchData=
[
  ['zest_55',['zest',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html#a6c5f88fbf1aa1f554a8cce43f4907e4a',1,'kitchen::ingredients::Ingredient::Lemon']]]
];
