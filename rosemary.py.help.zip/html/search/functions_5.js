var searchData=
[
  ['mix_100',['mix',['../classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#ab02bac8ad84aad9e83cb4b756068000e',1,'kitchen::utensils::Utensil::Bowl']]]
];
