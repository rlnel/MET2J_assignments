var searchData=
[
  ['chilledcollection_63',['ChilledCollection',['../classkitchen_1_1ingredients_1_1_collections_1_1_chilled_collection.html',1,'kitchen::ingredients::Collections']]],
  ['chocolatechips_64',['ChocolateChips',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_chocolate_chips.html',1,'kitchen::ingredients::Ingredient']]],
  ['cinnamon_65',['Cinnamon',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_cinnamon.html',1,'kitchen::ingredients::Ingredient']]],
  ['collection_66',['Collection',['../classkitchen_1_1ingredients_1_1_collections_1_1_collection.html',1,'kitchen::ingredients::Collections']]],
  ['cookedcollection_67',['CookedCollection',['../classkitchen_1_1ingredients_1_1_collections_1_1_cooked_collection.html',1,'kitchen::ingredients::Collections']]],
  ['cornstarch_68',['Cornstarch',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_cornstarch.html',1,'kitchen::ingredients::Ingredient']]]
];
