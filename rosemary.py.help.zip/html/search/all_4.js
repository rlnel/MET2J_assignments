var searchData=
[
  ['egg_18',['Egg',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_egg.html',1,'kitchen::ingredients::Ingredient']]]
];
