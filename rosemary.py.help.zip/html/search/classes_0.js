var searchData=
[
  ['apple_56',['Apple',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html',1,'kitchen::ingredients::Ingredient']]]
];
