var searchData=
[
  ['ingredient_22',['Ingredient',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_ingredient.html',1,'kitchen::ingredients::Ingredient']]]
];
