var searchData=
[
  ['milk_78',['Milk',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_milk.html',1,'kitchen::ingredients::Ingredient']]],
  ['mixture_79',['Mixture',['../classkitchen_1_1ingredients_1_1_collections_1_1_mixture.html',1,'kitchen::ingredients::Collections']]]
];
