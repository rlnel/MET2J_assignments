var searchData=
[
  ['chilledcollection_9',['ChilledCollection',['../classkitchen_1_1ingredients_1_1_collections_1_1_chilled_collection.html',1,'kitchen::ingredients::Collections']]],
  ['chocolatechips_10',['ChocolateChips',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_chocolate_chips.html',1,'kitchen::ingredients::Ingredient']]],
  ['cinnamon_11',['Cinnamon',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_cinnamon.html',1,'kitchen::ingredients::Ingredient']]],
  ['collection_12',['Collection',['../classkitchen_1_1ingredients_1_1_collections_1_1_collection.html',1,'kitchen::ingredients::Collections']]],
  ['cook_13',['cook',['../classkitchen_1_1utensils_1_1_utensil_1_1_pan.html#a9ce2653f9e66ffa976b1d2ceaf60864f',1,'kitchen::utensils::Utensil::Pan']]],
  ['cookedcollection_14',['CookedCollection',['../classkitchen_1_1ingredients_1_1_collections_1_1_cooked_collection.html',1,'kitchen::ingredients::Collections']]],
  ['cornstarch_15',['Cornstarch',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_cornstarch.html',1,'kitchen::ingredients::Ingredient']]],
  ['crack_16',['crack',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_egg.html#ad1b4cd651b90b1dd8f6b2c771b9c5877',1,'kitchen::ingredients::Ingredient::Egg']]]
];
