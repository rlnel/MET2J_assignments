var searchData=
[
  ['temperaturecollection_90',['TemperatureCollection',['../classkitchen_1_1ingredients_1_1_collections_1_1_temperature_collection.html',1,'kitchen::ingredients::Collections']]]
];
