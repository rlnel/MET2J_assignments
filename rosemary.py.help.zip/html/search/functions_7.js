var searchData=
[
  ['serve_103',['serve',['../classkitchen_1_1_rosemary_1_1_rosemary.html#af4344145e131277738b61f2cec2acc26',1,'kitchen::Rosemary::Rosemary']]],
  ['set_5ftemperature_104',['set_temperature',['../classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html#a584640c2cd84d476c8b18b6b95b63f3e',1,'kitchen::utensils::Utensil::Fridge']]],
  ['slice_105',['slice',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html#ab8e8680b3e4ca364e97faafb4569cb82',1,'kitchen::ingredients::Ingredient::Apple']]],
  ['squeeze_106',['squeeze',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html#a8678e2ddaa0d3c1a1d06d0fec7825eae',1,'kitchen::ingredients::Ingredient::Lemon']]]
];
