var searchData=
[
  ['flip_99',['flip',['../classkitchen_1_1utensils_1_1_utensil_1_1_pan.html#a223dbb87add79364140fb47b5ddb318e',1,'kitchen::utensils::Utensil::Pan']]]
];
