var searchData=
[
  ['peel_101',['peel',['../classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html#a5dc5910517e20e93928656c2493e2768',1,'kitchen::ingredients::Ingredient::Apple']]],
  ['preheat_102',['preheat',['../classkitchen_1_1utensils_1_1_utensil_1_1_oven.html#a511ef478aad7eda88463e1cb9f1c3858',1,'kitchen::utensils::Utensil::Oven']]]
];
