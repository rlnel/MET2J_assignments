var searchData=
[
  ['divide_17',['divide',['../classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#a2082716ebdfd393907bcc459d57b4abd',1,'kitchen::utensils::Utensil::Bowl']]]
];
