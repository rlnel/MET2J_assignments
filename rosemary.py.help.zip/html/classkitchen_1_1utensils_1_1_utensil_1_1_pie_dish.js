var classkitchen_1_1utensils_1_1_utensil_1_1_pie_dish =
[
    [ "take", "classkitchen_1_1utensils_1_1_utensil_1_1_pie_dish.html#aa071cfc13d852789ecbaac703de29f1c", null ]
];