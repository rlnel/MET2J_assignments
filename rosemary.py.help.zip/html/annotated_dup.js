var annotated_dup =
[
    [ "kitchen", null, [
      [ "ingredients", null, [
        [ "Collections", null, [
          [ "BakedCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_baked_collection.html", null ],
          [ "ChilledCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_chilled_collection.html", null ],
          [ "Collection", "classkitchen_1_1ingredients_1_1_collections_1_1_collection.html", null ],
          [ "CookedCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_cooked_collection.html", null ],
          [ "Mixture", "classkitchen_1_1ingredients_1_1_collections_1_1_mixture.html", null ],
          [ "PieCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_pie_collection.html", null ],
          [ "Portion", "classkitchen_1_1ingredients_1_1_collections_1_1_portion.html", null ],
          [ "Stack", "classkitchen_1_1ingredients_1_1_collections_1_1_stack.html", null ],
          [ "TemperatureCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_temperature_collection.html", null ]
        ] ],
        [ "Ingredient", null, [
          [ "Apple", "classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html", "classkitchen_1_1ingredients_1_1_ingredient_1_1_apple" ],
          [ "BakingPowder", "classkitchen_1_1ingredients_1_1_ingredient_1_1_baking_powder.html", null ],
          [ "Butter", "classkitchen_1_1ingredients_1_1_ingredient_1_1_butter.html", null ],
          [ "ChocolateChips", "classkitchen_1_1ingredients_1_1_ingredient_1_1_chocolate_chips.html", null ],
          [ "Cinnamon", "classkitchen_1_1ingredients_1_1_ingredient_1_1_cinnamon.html", null ],
          [ "Cornstarch", "classkitchen_1_1ingredients_1_1_ingredient_1_1_cornstarch.html", null ],
          [ "Egg", "classkitchen_1_1ingredients_1_1_ingredient_1_1_egg.html", "classkitchen_1_1ingredients_1_1_ingredient_1_1_egg" ],
          [ "Flour", "classkitchen_1_1ingredients_1_1_ingredient_1_1_flour.html", null ],
          [ "Ingredient", "classkitchen_1_1ingredients_1_1_ingredient_1_1_ingredient.html", null ],
          [ "Lemon", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon" ],
          [ "LemonJuice", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon_juice.html", null ],
          [ "LemonZest", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon_zest.html", null ],
          [ "Milk", "classkitchen_1_1ingredients_1_1_ingredient_1_1_milk.html", null ],
          [ "Salt", "classkitchen_1_1ingredients_1_1_ingredient_1_1_salt.html", null ],
          [ "Sugar", "classkitchen_1_1ingredients_1_1_ingredient_1_1_sugar.html", null ],
          [ "UncountableIngredient", "classkitchen_1_1ingredients_1_1_ingredient_1_1_uncountable_ingredient.html", "classkitchen_1_1ingredients_1_1_ingredient_1_1_uncountable_ingredient" ],
          [ "Water", "classkitchen_1_1ingredients_1_1_ingredient_1_1_water.html", null ]
        ] ]
      ] ],
      [ "Kitchen", null, [
        [ "KitchenException", "classkitchen_1_1_kitchen_1_1_kitchen_exception.html", null ],
        [ "KitchenObject", "classkitchen_1_1_kitchen_1_1_kitchen_object.html", null ]
      ] ],
      [ "Rosemary", null, [
        [ "Rosemary", "classkitchen_1_1_rosemary_1_1_rosemary.html", null ]
      ] ],
      [ "utensils", null, [
        [ "Utensil", null, [
          [ "BakingTray", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_tray.html", null ],
          [ "BakingUtensil", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil.html", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil" ],
          [ "Bowl", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl" ],
          [ "Fridge", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge" ],
          [ "Oven", "classkitchen_1_1utensils_1_1_utensil_1_1_oven.html", "classkitchen_1_1utensils_1_1_utensil_1_1_oven" ],
          [ "Pan", "classkitchen_1_1utensils_1_1_utensil_1_1_pan.html", "classkitchen_1_1utensils_1_1_utensil_1_1_pan" ],
          [ "PieDish", "classkitchen_1_1utensils_1_1_utensil_1_1_pie_dish.html", "classkitchen_1_1utensils_1_1_utensil_1_1_pie_dish" ],
          [ "Plate", "classkitchen_1_1utensils_1_1_utensil_1_1_plate.html", "classkitchen_1_1utensils_1_1_utensil_1_1_plate" ],
          [ "Utensil", "classkitchen_1_1utensils_1_1_utensil_1_1_utensil.html", null ]
        ] ]
      ] ]
    ] ]
];