var classkitchen_1_1ingredients_1_1_ingredient_1_1_apple =
[
    [ "peel", "classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html#a5dc5910517e20e93928656c2493e2768", null ],
    [ "slice", "classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html#ab8e8680b3e4ca364e97faafb4569cb82", null ]
];