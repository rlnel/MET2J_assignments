var classkitchen_1_1ingredients_1_1_ingredient_1_1_egg =
[
    [ "crack", "classkitchen_1_1ingredients_1_1_ingredient_1_1_egg.html#ad1b4cd651b90b1dd8f6b2c771b9c5877", null ]
];