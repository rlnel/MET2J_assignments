var classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil =
[
    [ "add", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil.html#ade702e8d38a39fc4c490a5b7079b53fd", null ],
    [ "take", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil.html#a9db0f48aef273a991d2a506a784f2596", null ]
];