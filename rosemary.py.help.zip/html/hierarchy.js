var hierarchy =
[
    [ "Exception", null, [
      [ "KitchenException", "classkitchen_1_1_kitchen_1_1_kitchen_exception.html", null ]
    ] ],
    [ "KitchenObject", "classkitchen_1_1_kitchen_1_1_kitchen_object.html", [
      [ "Ingredient", "classkitchen_1_1ingredients_1_1_ingredient_1_1_ingredient.html", [
        [ "Collection", "classkitchen_1_1ingredients_1_1_collections_1_1_collection.html", [
          [ "CookedCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_cooked_collection.html", null ],
          [ "Mixture", "classkitchen_1_1ingredients_1_1_collections_1_1_mixture.html", null ],
          [ "Stack", "classkitchen_1_1ingredients_1_1_collections_1_1_stack.html", null ],
          [ "TemperatureCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_temperature_collection.html", [
            [ "BakedCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_baked_collection.html", [
              [ "PieCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_pie_collection.html", null ]
            ] ],
            [ "ChilledCollection", "classkitchen_1_1ingredients_1_1_collections_1_1_chilled_collection.html", null ]
          ] ]
        ] ],
        [ "Portion", "classkitchen_1_1ingredients_1_1_collections_1_1_portion.html", null ],
        [ "Apple", "classkitchen_1_1ingredients_1_1_ingredient_1_1_apple.html", null ],
        [ "Egg", "classkitchen_1_1ingredients_1_1_ingredient_1_1_egg.html", null ],
        [ "Lemon", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html", null ],
        [ "UncountableIngredient", "classkitchen_1_1ingredients_1_1_ingredient_1_1_uncountable_ingredient.html", [
          [ "BakingPowder", "classkitchen_1_1ingredients_1_1_ingredient_1_1_baking_powder.html", null ],
          [ "Butter", "classkitchen_1_1ingredients_1_1_ingredient_1_1_butter.html", null ],
          [ "ChocolateChips", "classkitchen_1_1ingredients_1_1_ingredient_1_1_chocolate_chips.html", null ],
          [ "Cinnamon", "classkitchen_1_1ingredients_1_1_ingredient_1_1_cinnamon.html", null ],
          [ "Cornstarch", "classkitchen_1_1ingredients_1_1_ingredient_1_1_cornstarch.html", null ],
          [ "Flour", "classkitchen_1_1ingredients_1_1_ingredient_1_1_flour.html", null ],
          [ "LemonJuice", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon_juice.html", null ],
          [ "LemonZest", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon_zest.html", null ],
          [ "Milk", "classkitchen_1_1ingredients_1_1_ingredient_1_1_milk.html", null ],
          [ "Salt", "classkitchen_1_1ingredients_1_1_ingredient_1_1_salt.html", null ],
          [ "Sugar", "classkitchen_1_1ingredients_1_1_ingredient_1_1_sugar.html", null ],
          [ "Water", "classkitchen_1_1ingredients_1_1_ingredient_1_1_water.html", null ]
        ] ]
      ] ],
      [ "Utensil", "classkitchen_1_1utensils_1_1_utensil_1_1_utensil.html", [
        [ "BakingUtensil", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_utensil.html", [
          [ "BakingTray", "classkitchen_1_1utensils_1_1_utensil_1_1_baking_tray.html", null ],
          [ "PieDish", "classkitchen_1_1utensils_1_1_utensil_1_1_pie_dish.html", null ]
        ] ],
        [ "Bowl", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html", null ],
        [ "Fridge", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html", null ],
        [ "Oven", "classkitchen_1_1utensils_1_1_utensil_1_1_oven.html", null ],
        [ "Pan", "classkitchen_1_1utensils_1_1_utensil_1_1_pan.html", null ],
        [ "Plate", "classkitchen_1_1utensils_1_1_utensil_1_1_plate.html", null ]
      ] ]
    ] ],
    [ "Rosemary", "classkitchen_1_1_rosemary_1_1_rosemary.html", null ]
];