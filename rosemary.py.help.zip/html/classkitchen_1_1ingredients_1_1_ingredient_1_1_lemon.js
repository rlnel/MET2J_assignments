var classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon =
[
    [ "squeeze", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html#a8678e2ddaa0d3c1a1d06d0fec7825eae", null ],
    [ "zest", "classkitchen_1_1ingredients_1_1_ingredient_1_1_lemon.html#a6c5f88fbf1aa1f554a8cce43f4907e4a", null ]
];