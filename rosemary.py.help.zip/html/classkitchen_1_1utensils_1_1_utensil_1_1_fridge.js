var classkitchen_1_1utensils_1_1_utensil_1_1_fridge =
[
    [ "add", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html#a36493a193934d031931bb584511ba09b", null ],
    [ "set_temperature", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html#a584640c2cd84d476c8b18b6b95b63f3e", null ],
    [ "take", "classkitchen_1_1utensils_1_1_utensil_1_1_fridge.html#a5fd53c9f6ec15c28709e9f18bde903d3", null ]
];