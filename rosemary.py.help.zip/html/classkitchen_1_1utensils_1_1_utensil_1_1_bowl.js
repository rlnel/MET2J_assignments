var classkitchen_1_1utensils_1_1_utensil_1_1_bowl =
[
    [ "add", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#ade702e8d38a39fc4c490a5b7079b53fd", null ],
    [ "divide", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#a2082716ebdfd393907bcc459d57b4abd", null ],
    [ "mix", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#ab02bac8ad84aad9e83cb4b756068000e", null ],
    [ "take", "classkitchen_1_1utensils_1_1_utensil_1_1_bowl.html#adbd37708ed3a46461434650f754d299b", null ]
];