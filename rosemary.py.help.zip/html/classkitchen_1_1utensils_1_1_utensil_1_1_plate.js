var classkitchen_1_1utensils_1_1_utensil_1_1_plate =
[
    [ "add", "classkitchen_1_1utensils_1_1_utensil_1_1_plate.html#ade702e8d38a39fc4c490a5b7079b53fd", null ]
];